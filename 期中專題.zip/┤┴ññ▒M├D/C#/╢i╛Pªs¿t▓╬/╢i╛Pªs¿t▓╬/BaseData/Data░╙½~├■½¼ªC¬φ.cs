﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 進銷存系統.BaseData
{
    public class Data商品類型列表
    {
        public int 商品類型ID { get; set; }
        public string 商品類型名稱 { get; set; }
    }
}
