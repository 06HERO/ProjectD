﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 進銷存系統.BaseData
{
    public class Data廠商列表
    {
        public int 廠商ID { get; set; }
        public string 廠商名稱 { get; set; }
    }
}
