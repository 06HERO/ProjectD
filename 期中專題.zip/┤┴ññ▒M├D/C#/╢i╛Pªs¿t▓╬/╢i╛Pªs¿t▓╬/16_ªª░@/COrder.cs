﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 進銷存系統
{
    public class COrder
    {
        public int 訂單編號 { get; set; }
        public string 聯絡人 { get; set; }
        public string 聯絡電話 { get; set; }
        public string 地址 { get; set; }
        public string 備註 { get; set; }
        public int 經銷商ID { get; set; }
        public string 訂單日期 { get; set; }
        public string 交貨日期 { get; set; }
        public string 訂單狀態 { get; set; }
    }

  






}
