﻿namespace 進銷存系統
{
    partial class Frm_廠商維護_新增表
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lB_廠商維護編輯 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tB_廠商名稱 = new System.Windows.Forms.TextBox();
            this.tB_統一編號 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tB_代表人姓名 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tB_資本總額 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tB_聯絡電話 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.bTn_確定 = new System.Windows.Forms.Button();
            this.bTn_取消 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lB_廠商維護編輯
            // 
            this.lB_廠商維護編輯.BackColor = System.Drawing.Color.IndianRed;
            this.lB_廠商維護編輯.Dock = System.Windows.Forms.DockStyle.Top;
            this.lB_廠商維護編輯.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lB_廠商維護編輯.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lB_廠商維護編輯.Location = new System.Drawing.Point(0, 0);
            this.lB_廠商維護編輯.Name = "lB_廠商維護編輯";
            this.lB_廠商維護編輯.Size = new System.Drawing.Size(369, 82);
            this.lB_廠商維護編輯.TabIndex = 0;
            this.lB_廠商維護編輯.Text = "　廠商資料編輯";
            this.lB_廠商維護編輯.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(23, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "廠商名稱";
            // 
            // tB_廠商名稱
            // 
            this.tB_廠商名稱.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tB_廠商名稱.Location = new System.Drawing.Point(27, 117);
            this.tB_廠商名稱.Name = "tB_廠商名稱";
            this.tB_廠商名稱.Size = new System.Drawing.Size(256, 30);
            this.tB_廠商名稱.TabIndex = 2;
            // 
            // tB_統一編號
            // 
            this.tB_統一編號.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tB_統一編號.Location = new System.Drawing.Point(26, 172);
            this.tB_統一編號.Name = "tB_統一編號";
            this.tB_統一編號.Size = new System.Drawing.Size(256, 30);
            this.tB_統一編號.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(22, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 19);
            this.label2.TabIndex = 3;
            this.label2.Text = "統一編號";
            // 
            // tB_代表人姓名
            // 
            this.tB_代表人姓名.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tB_代表人姓名.Location = new System.Drawing.Point(26, 227);
            this.tB_代表人姓名.Name = "tB_代表人姓名";
            this.tB_代表人姓名.Size = new System.Drawing.Size(256, 30);
            this.tB_代表人姓名.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(22, 205);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 19);
            this.label3.TabIndex = 5;
            this.label3.Text = "代表人姓名";
            // 
            // tB_資本總額
            // 
            this.tB_資本總額.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tB_資本總額.Location = new System.Drawing.Point(26, 282);
            this.tB_資本總額.Name = "tB_資本總額";
            this.tB_資本總額.Size = new System.Drawing.Size(256, 30);
            this.tB_資本總額.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(22, 260);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 19);
            this.label4.TabIndex = 7;
            this.label4.Text = "資本總額";
            // 
            // tB_聯絡電話
            // 
            this.tB_聯絡電話.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tB_聯絡電話.Location = new System.Drawing.Point(26, 337);
            this.tB_聯絡電話.Name = "tB_聯絡電話";
            this.tB_聯絡電話.Size = new System.Drawing.Size(256, 30);
            this.tB_聯絡電話.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(22, 315);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 19);
            this.label5.TabIndex = 9;
            this.label5.Text = "聯絡電話";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label6.Location = new System.Drawing.Point(4, 380);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(365, 2);
            this.label6.TabIndex = 11;
            // 
            // bTn_確定
            // 
            this.bTn_確定.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.bTn_確定.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.bTn_確定.Location = new System.Drawing.Point(263, 394);
            this.bTn_確定.Name = "bTn_確定";
            this.bTn_確定.Size = new System.Drawing.Size(80, 44);
            this.bTn_確定.TabIndex = 12;
            this.bTn_確定.Text = "確定";
            this.bTn_確定.UseVisualStyleBackColor = true;
            this.bTn_確定.Click += new System.EventHandler(this.bTn_確定_Click);
            // 
            // bTn_取消
            // 
            this.bTn_取消.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.bTn_取消.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.bTn_取消.Location = new System.Drawing.Point(177, 394);
            this.bTn_取消.Name = "bTn_取消";
            this.bTn_取消.Size = new System.Drawing.Size(80, 44);
            this.bTn_取消.TabIndex = 13;
            this.bTn_取消.Text = "取消";
            this.bTn_取消.UseVisualStyleBackColor = true;
            this.bTn_取消.Click += new System.EventHandler(this.bTn_取消_Click);
            // 
            // Frm_廠商維護_新增表
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(369, 450);
            this.Controls.Add(this.bTn_取消);
            this.Controls.Add(this.bTn_確定);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tB_聯絡電話);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tB_資本總額);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tB_代表人姓名);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tB_統一編號);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tB_廠商名稱);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lB_廠商維護編輯);
            this.Name = "Frm_廠商維護_新增表";
            this.Text = "Frm_廠商維護_新增表";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lB_廠商維護編輯;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tB_廠商名稱;
        private System.Windows.Forms.TextBox tB_統一編號;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tB_代表人姓名;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tB_資本總額;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tB_聯絡電話;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button bTn_確定;
        private System.Windows.Forms.Button bTn_取消;
    }
}